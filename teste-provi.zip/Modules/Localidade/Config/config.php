<?php

return [
    'name' => 'Localidade'
];
