<?php

namespace Modules\Localidade\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface BairroRepository
 * @package namespace Modules\Localidade\Repositories;
 */
interface BairroRepository extends RepositoryInterface
{
    //
}
