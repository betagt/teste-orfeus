<?php

namespace Modules\Localidade\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface TelefoneRepository
 * @package namespace Modules\Localidade\Repositories;
 */
interface TelefoneRepository extends RepositoryInterface
{
    //
}
