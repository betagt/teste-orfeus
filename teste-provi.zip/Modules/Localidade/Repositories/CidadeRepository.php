<?php

namespace Modules\Localidade\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CidadeRepository
 * @package namespace Modules\Localidade\Repositories;
 */
interface CidadeRepository extends RepositoryInterface
{
    //
}
