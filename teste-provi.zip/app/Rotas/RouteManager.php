<?php
/**
 * Created by PhpStorm.
 * User: dsoft
 * Date: 06/02/2017
 * Time: 16:10
 */

namespace Portal\Rotas;

use Portal\Interfaces\ICustomRoute;

class RouteManager implements ICustomRoute
{

    public static function run()
    {

    }
}