<?php
/**
 * Created by PhpStorm.
 * User: dsoft
 * Date: 02/01/2017
 * Time: 15:19
 */

namespace Portal\Transformers;

use League\Fractal\TransformerAbstract;

class BaseTransformer extends TransformerAbstract
{
    //**foo
}