<?php

namespace Portal\Criteria;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Class PaginaCriteria
 * @package namespace Portal\Criteria;
 */
class PaginaCriteria extends BaseCriteria
{

}
