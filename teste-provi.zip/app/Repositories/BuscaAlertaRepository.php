<?php

namespace Portal\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface BuscaAlertaRepository
 * @package namespace Portal\Repositories;
 */
interface BuscaAlertaRepository extends RepositoryInterface
{
    //
}
