<?php

namespace Portal\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ConfiguracaoRepository
 * @package namespace Portal\Repositories;
 */
interface ConfiguracaoRepository extends RepositoryInterface
{
    //
}
