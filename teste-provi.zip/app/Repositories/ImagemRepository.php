<?php

namespace Portal\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ImagemRepository
 * @package namespace Portal\Repositories;
 */
interface ImagemRepository extends RepositoryInterface
{
    //
}
