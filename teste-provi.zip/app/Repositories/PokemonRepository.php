<?php

namespace Portal\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PokemonRepository
 * @package namespace Portal\Repositories;
 */
interface PokemonRepository extends RepositoryInterface
{
    //
}
