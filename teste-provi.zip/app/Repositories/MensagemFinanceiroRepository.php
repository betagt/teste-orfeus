<?php

namespace Portal\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface MensagemFinanceiroRepository
 * @package namespace Portal\Repositories;
 */
interface MensagemFinanceiroRepository extends RepositoryInterface
{
    //
}
