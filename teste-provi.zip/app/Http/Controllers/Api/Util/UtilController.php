<?php

namespace Portal\Http\Controllers\Api\Util;

use Portal\Http\Controllers\Controller;

class UtilController extends Controller
{

}
