<?php
namespace Portal\Interfaces;
/**
 * Created by PhpStorm.
 * User: dsoft
 * Date: 06/02/2017
 * Time: 15:31
 */
interface ICustomRoute
{
    public static function run();
}