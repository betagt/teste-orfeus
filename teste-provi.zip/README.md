POST    /cadastro
/admin/user/registrar

POST    /login
/api/v1/oauth/token

GET     /pokemons
/api/v1/front/pokemon

GET     /pokemon/:id
/api/v1/front/pokemon/{id}


POST    /pokemon/add
/api/v1/front/pokemon/add

{
    nome:'string'
}

PUT     /pokemon/:id
/api/v1/front/pokemon/{id}


{
    nome:'string'
}

DELETE  /pokemon/:id
/api/v1/front/pokemon/{id}