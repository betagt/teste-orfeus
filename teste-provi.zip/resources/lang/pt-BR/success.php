<?php
return [
    'client'=>[
        "revoke"=> "Permissão revogada!",
    ]
];